import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-movie-list',
  imports: [CommonModule, RouterLink],
  templateUrl: './movie-list.component.html',
  styleUrl: './movie-list.component.css',
})
export class MovieListComponent implements OnInit {
  movies: any[] = [];

  ngOnInit(): void {
    const moviesData = localStorage.getItem('movies');
    this.movies = moviesData && JSON.parse(moviesData);
  }

  constructor(private router: Router) {}
}

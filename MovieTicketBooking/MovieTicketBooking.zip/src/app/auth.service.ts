import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private isLoggedIn = false;

  // Signup Method: Stores user details in localStorage
  signup(data: any) {
    debugger;
    let users = this.getUsers();
    users.push(data);
    localStorage.setItem('users', JSON.stringify(users));
  }

  // Login Method: Checks if user exists in localStorage
  login(email: string, password: string): boolean {
    let users = this.getUsers();
    const user = users.find(
      (u) => u.email === email && u.password === password
    );
    this.isLoggedIn = !!user;
    if (this.isLoggedIn) {
      localStorage.setItem('currentUser', JSON.stringify(user));
    }
    return this.isLoggedIn;
  }

  // Logout Method: Removes currentUser from localStorage
  logout() {
    this.isLoggedIn = false;
    localStorage.removeItem('currentUser');
  }

  // Check if the user is authenticated
  isAuthenticated(): boolean {
    return !!localStorage.getItem('currentUser');
  }

  // Retrieve all users from localStorage
  private getUsers(): any[] {
    let users = localStorage.getItem('users');
    return users ? JSON.parse(users) : [];
  }
}

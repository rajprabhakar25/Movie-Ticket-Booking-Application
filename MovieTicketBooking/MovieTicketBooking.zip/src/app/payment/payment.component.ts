import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './payment.component.html',
  styleUrl: './payment.component.css',
})
export class PaymentComponent implements OnInit {
  selectedSeats: any[] = [];
  totalPrice: number = 0;
  showTime: string = '';
  showDate: string = '';

  gstPercentage: number = 18; // GST percentage

  constructor(private router: Router) {}

  ngOnInit(): void {
    const navigation = this.router.getCurrentNavigation();
    console.log(navigation?.extras);
    if (navigation?.extras?.state) {
      const state = navigation.extras.state as {
        selectedSeats: any[];
        totalPrice: number;
        showTime: string;
        showDate: string;
      };
      this.selectedSeats = state.selectedSeats || [];
      this.totalPrice = state.totalPrice || 0;
      this.showTime = state.showTime || '';
      this.showDate = state.showDate || '';
    } else {
      // Handle the case where state is not available
      console.error('No state data available.');
    }
  }

  getSelectedSeatsString(): string {
    return this.selectedSeats.map((seat) => seat.number).join(', ');
  }

  // Calculate total amount including GST
  getTotalAmountWithGST() {
    const gstAmount = (this.totalPrice * this.gstPercentage) / 100;
    return this.totalPrice + gstAmount;
  }
}

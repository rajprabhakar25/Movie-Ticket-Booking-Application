import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../auth.service';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-home',
  imports: [CommonModule, RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css',
})
export class HomeComponent implements OnInit {
  user: any | null;
  userName: string | null;

  featuredMovies = [
    {
      id: 1,
      title: 'The Greatest of All Time',
      description:
        'Consequences of an unknown past haunt the present of a special anti-terrorist squad. How will they confront it?',
      imageUrl: 'assets/images/GOAT.jpg',
    },
    {
      id: 2,
      title: 'A.R.M',
      description:
        "Set in Northern Kerala across the years 1900, 1950, and 1990, this epic tale follows three generations of heroes Maniyan, Kunjikelu, and Ajayan as they strive to protect the land's most vital treasure.",
      imageUrl: 'assets/images/ARM.jpeg',
    },
    {
      id: 3,
      title: 'Deadpool & Wolverine',
      description:
        'Wolverine is recovering from his injuries when he meets the loudmouth, Deadpool. They team up to defeat a common enemy.',
      imageUrl: 'assets/images/deadpool_wolverine.webp',
    },
    {
      id: 4,
      title: 'Joker: Folie a Deux',
      description:
        '"Joker: Folie A Deux" finds Arthur Fleck institutionalized at Arkham awaiting trial for his crimes as Joker. While struggling with his dual identity, Arthur not only stumbles upon true love, but also finds the music that`s always been inside him.',
      imageUrl: 'assets/images/joker.jpg',
    },
    {
      id: 5,
      title: 'Vaazhai',
      description:
        '12-year-old Sivanaindhan lives with his mother, sister, and friend in the village of Plantain Plantations. Hoping to seek a merry life, he lugs Plantains even during school holidays. Will his hard work pay off?',
      imageUrl: 'assets/images/vaazhai.jpg',
    },
    {
      id: 6,
      title: 'Demonte Colony 2 - Vengeance Of The Unholy',
      description:
        'Demonte Colony 2 - Vengeance Of The Unholy is a Tamil movie starring Arulnithi Tamilarasu, Priya Bhavani Shankar, Meenakshi Govindarajan, Archana Chandhoke and Sarjano Khalid in prominent roles. It is written and directed by R. Ajay Gnanamuthu.',
      imageUrl: 'assets/images/demonte-colony-2.jpg',
    },
    {
      id: 7,
      title: 'Speak No Evil',
      description:
        "A dream holiday turns into a living nightmare when an American couple and their daughter spend the weekend at a British family's idyllic country estate.",
      imageUrl: 'assets/images/speak-no-evil.jpg',
    },
    {
      id: 8,
      title: 'Strange Darling',
      description: 'One day in the twisted love life of a serial killer.',
      imageUrl: 'assets/images/strange-darling.jpg',
    },
    {
      id: 9,
      title: 'Alien: Romulus',
      description:
        'While scavenging the deep ends of a derelict space station, a group of young space colonizers face the most terrifying life form in the universe.',
      imageUrl: 'assets/images/alien-romulus.jpg',
    },
    {
      id: 10,
      title: 'Beetlejuice Beetlejuice',
      description:
        'After an unexpected family tragedy, three generations of the Deetz family return home to Winter River. Still haunted by Beetlejuice, Lydia`s life is turned upside down when her rebellious teenage daughter, Astrid, discovers the mysterious model of the town in the attic, and the portal to the Afterlife is accidentally opened.',
      imageUrl: 'assets/images/beetlejuice.jpg',
    },
  ];

  theatresData = {
    1: [
      {
        name: 'The Vijay Park Multiplex: Injambakkam ECR 4K Atmos',
        timings: ['10:00 AM', '1:00 PM', '4:00 PM', '7:00 PM'],
      },
      {
        name: 'MAYAJAAL Multiplex: ECR, Chennai',
        timings: ['11:00 AM', '2:00 PM', '5:00 PM'],
      },
      {
        name: 'INOX: LUKE Phoenix Market City, Velachery',
        timings: [
          '5:40 AM',
          '5:55 PM',
          '6:10 PM',
          '6:20 PM',
          '6:35 PM',
          '9:15 PM',
          '9:30 PM',
        ],
      },
    ],
    2: [
      {
        name: 'The Vijay Park Multiplex: Injambakkam ECR 4K Atmos',
        timings: ['12:00 PM', '3:00 PM', '6:00 PM'],
      },
    ],
    3: [
      {
        name: 'MAYAJAAL Multiplex: ECR, Chennai',
        timings: ['9:00 AM', '12:00 PM', '6:00 PM'],
      },
      {
        name: 'AGS Cinemas: Villivakkam',
        timings: ['2:00 PM', '5:00 PM', '9:00 PM'],
      },
    ],
    4: [
      {
        name: 'The Vijay Park Multiplex: Injambakkam ECR 4K Atmos',
        timings: ['2:00 PM', '5:00 PM', '9:00 PM'],
      },
      {
        name: 'INOX: LUKE Phoenix Market City, Velachery',
        timings: [
          '5:40 AM',
          '5:55 PM',
          '6:10 PM',
          '6:20 PM',
          '6:35 PM',
          '9:15 PM',
          '9:30 PM',
        ],
      },
    ],
    5: [
      {
        name: 'AGS Cinemas: Villivakkam',
        timings: ['9:00 AM', '12:00 PM', '6:00 PM'],
      },
      {
        name: 'The Vijay Park Multiplex: Injambakkam ECR 4K Atmos',
        timings: ['2:00 PM', '5:00 PM', '9:00 PM'],
      },
      {
        name: 'INOX: LUKE Phoenix Market City, Velachery',
        timings: [
          '5:40 AM',
          '5:55 PM',
          '6:10 PM',
          '6:20 PM',
          '6:35 PM',
          '9:15 PM',
          '9:30 PM',
        ],
      },
    ],
    6: [
      {
        name: 'AGS Cinemas: Villivakkam',
        timings: ['5:00 PM', '9:00 PM'],
      },
    ],
    7: [
      {
        name: 'MAYAJAAL Multiplex: ECR, Chennai',
        timings: ['9:00 AM', '12:00 PM', '6:00 PM'],
      },
      {
        name: 'AGS Cinemas: Villivakkam',
        timings: ['2:00 PM', '5:00 PM', '9:00 PM'],
      },
      {
        name: 'INOX: LUKE Phoenix Market City, Velachery',
        timings: [
          '5:40 AM',
          '5:55 PM',
          '6:10 PM',
          '6:20 PM',
          '6:35 PM',
          '9:15 PM',
          '9:30 PM',
        ],
      },
    ],
    8: [
      {
        name: 'MAYAJAAL Multiplex: ECR, Chennai',
        timings: ['3:00 PM', '5:00 PM', '7:00 PM', '9:15 PM'],
      },
      {
        name: 'The Vijay Park Multiplex: Injambakkam ECR 4K Atmos',
        timings: ['2:00 PM', '5:00 PM', '9:00 PM'],
      },
    ],
    9: [
      {
        name: 'INOX: LUKE Phoenix Market City, Velachery',
        timings: ['2:30 AM', '6:30 PM', '10:00 PM'],
      },
      {
        name: 'AGS Cinemas: Villivakkam',
        timings: ['2:00 PM', '5:00 PM', '9:00 PM', '10:20 PM', '10:50 PM'],
      },
    ],
    10: [
      {
        name: 'AGS Cinemas: Villivakkam',
        timings: [
          '5:40 AM',
          '5:55 PM',
          '6:10 PM',
          '6:20 PM',
          '6:35 PM',
          '9:15 PM',
          '9:30 PM',
        ],
      },
      {
        name: 'INOX: LUKE Phoenix Market City, Velachery',
        timings: [
          '5:40 PM',
          '5:55 PM',
          '6:15 PM',
          '9:15 PM',
          '9:15 PM',
          '10:10 PM',
        ],
      },
    ],
  };

  ngOnInit() {
    localStorage.setItem('movies', JSON.stringify(this.featuredMovies));
    localStorage.setItem('theatres', JSON.stringify(this.theatresData));
  }

  // bookMovie(movieId: number) {
  //   console.log('Book movie with ID: ', movieId);
  //   // Navigate to booking page or handle booking logic here
  // }

  constructor(private router: Router) {
    // Retrieve the logged-in user's name from localStorage
    this.user = this.getData();
    if (this.user) {
      this.userName = this.user.name;
    } else {
      this.userName = '';
    }
    // Assuming the name is saved during login
  }

  getData() {
    let user = localStorage.getItem('currentUser');
    return user ? JSON.parse(user) : [];
  }

  // logout() {
  //   this.authService.logout();
  //   this.router.navigate(['/login']);
  // }
}

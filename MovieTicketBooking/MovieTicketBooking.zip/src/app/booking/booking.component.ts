import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { FormsModule } from '@angular/forms';

@Component({
  standalone: true,
  imports: [FormsModule],
  selector: 'app-booking',
  templateUrl: './booking.component.html',
})
export class BookingComponent {
  movieTitle = 'Movie A'; // This would come from route params or service in real scenario
  tickets = 1;
  ticketPrice = 10;

  constructor(private route: ActivatedRoute, private router: Router) {}

  bookTickets() {
    // You can store booking data or pass it via navigation state to the dashboard
    alert('Booking Confirmed!');
    this.router.navigate(['/dashboard']);
  }
}

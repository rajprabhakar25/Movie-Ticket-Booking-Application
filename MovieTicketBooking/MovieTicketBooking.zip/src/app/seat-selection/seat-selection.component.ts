import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  SimpleChanges,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NavigationExtras, Router } from '@angular/router';

@Component({
  standalone: true,
  imports: [FormsModule, CommonModule],
  selector: 'app-seat-selection',
  templateUrl: './seat-selection.component.html',
  styleUrls: ['./seat-selection.component.css'],
})
export class SeatSelectionComponent implements OnInit {
  @Input() showTime: string = '';
  @Input() showDate: string | null = null;
  @Input() movieId: string | null = null;
  @Output() close = new EventEmitter<void>();
  @Output() confirmBooking = new EventEmitter<{
    selectedSeats: any[];
    totalPrice: number;
    showTime: string;
    showDate: string;
  }>();

  seats: any[] = [
    [
      { number: 'A1', price: 90, selected: false, booked: false },
      { number: 'A2', price: 90, selected: false, booked: false },
      { number: 'A3', price: 90, selected: false, booked: false },
      { number: 'A4', price: 90, selected: false, booked: false },
      { number: 'A5', price: 90, selected: false, booked: false },
    ],
    [
      { number: 'B1', price: 120, selected: false, booked: false },
      { number: 'B2', price: 120, selected: false, booked: false },
      { number: 'B3', price: 120, selected: false, booked: false },
      { number: 'B4', price: 120, selected: false, booked: false },
      { number: 'B5', price: 120, selected: false, booked: false },
    ],
    [
      { number: 'C1', price: 150, selected: false, booked: false },
      { number: 'C2', price: 150, selected: false, booked: false },
      { number: 'C3', price: 150, selected: false, booked: false },
      { number: 'C4', price: 150, selected: false, booked: false },
      { number: 'C5', price: 150, selected: false, booked: false },
    ],
    [
      { number: 'D1', price: 180, selected: false, booked: false },
      { number: 'D2', price: 180, selected: false, booked: false },
      { number: 'D3', price: 180, selected: false, booked: false },
      { number: 'D4', price: 180, selected: false, booked: false },
      { number: 'D5', price: 180, selected: false, booked: false },
    ],
    [
      { number: 'E1', price: 230, selected: false, booked: false },
      { number: 'E2', price: 230, selected: false, booked: false },
      { number: 'E3', price: 230, selected: false, booked: false },
      { number: 'E4', price: 230, selected: false, booked: false },
      { number: 'E5', price: 230, selected: false, booked: false },
    ],
    [
      { number: 'F1', price: 290, selected: false, booked: false },
      { number: 'F2', price: 290, selected: false, booked: false },
      { number: 'F3', price: 290, selected: false, booked: false },
      { number: 'F4', price: 290, selected: false, booked: false },
      { number: 'F5', price: 290, selected: false, booked: false },
    ],
  ];

  selectedSeats: number[] = [];
  totalPrice: number = 0;

  bookedSeats: { [key: string]: number[] } = {};

  constructor(private router: Router) {}

  ngOnInit(): void {
    this.loadSeats();
  }

  ngOnChanges(changes: SimpleChanges) {
    // if (changes['showTime']) {
    //   this.deselectAllSeats(); // Reset seats when showTime changes
    // }
    this.loadSeats();
  }

  loadSeats() {
    debugger;
    const bookedSeats = localStorage.getItem(
      `${this.movieId}-${this.showDate}-${this.showTime}`
    );
    if (bookedSeats) {
      const bookedSeatNumbers = JSON.parse(bookedSeats);
      this.seats.forEach((row) => {
        row.forEach((seat: { number: any; booked: boolean }) => {
          if (bookedSeatNumbers.includes(seat.number)) {
            seat.booked = true;
          }
        });
      });
    }
  }

  closeModal() {
    // const modal = document.getElementById('seatSelectionModal');
    // if (modal) {
    //   modal.style.display = 'none';
    // }
    this.close.emit();
  }

  selectSeat(row: number, col: number) {
    const seat = this.seats[row][col];
    seat.selected = !seat.selected;

    if (seat.selected) {
      this.selectedSeats.push(seat);
    } else {
      this.selectedSeats = this.selectedSeats.filter((s) => s !== seat);
    }
    this.calculateTotalPrice();
  }

  calculateTotalPrice() {
    debugger;
    const selectedSeats = this.seats.flat().filter((seat) => seat.selected);
    this.totalPrice = selectedSeats.reduce((acc, seat) => acc + seat.price, 0);
  }

  proceedToPayment() {
    this.calculateTotalPrice();

    const navigationExtras: NavigationExtras = {
      state: {
        totalPrice: this.totalPrice,
      },
    };

    this.router.navigate(['/dashboard/payment'], navigationExtras);
  }

  changeTiming(newTiming: string) {
    this.showTime = newTiming;
    this.deselectAllSeats();
  }

  deselectAllSeats() {
    this.seats.forEach((row) =>
      row.forEach(
        (seat: { selected: boolean; booked: boolean }) =>
          (seat.selected = false)
      )
    );
    this.selectedSeats = [];
  }

  bookSeats() {
    this.calculateTotalPrice(); // Calculate total price before proceeding

    debugger;
    const navigationExtras: NavigationExtras = {
      state: {
        selectedSeats: this.selectedSeats,
        totalPrice: this.totalPrice,
        showTime: this.showTime,
        showDate: this.showDate,
      },
    };

    this.router.navigate(['/dashboard/payment'], navigationExtras); // Navigate to the payment page with data
  }

  // bookSeats() {
  //   this.confirmBooking.emit({
  //     selectedSeats: this.selectedSeats,
  //     showTime: this.showTime!,
  //     showDate: this.showDate!,
  //   });
  // }

  confirmSelection() {
    const selectedSeats = this.seats.flat().filter((seat) => seat.selected);
    console.log('Selected seats:', selectedSeats);
    this.closeModal();
  }
}

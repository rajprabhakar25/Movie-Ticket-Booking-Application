import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'MovieTicketBooking';

  showNavbar = false; // Default value to show navbar

  constructor(private router: Router) {
    // Listen to route changes
    this.router.events.subscribe(() => {
      // Check the current URL
      this.showNavbar =
        this.router.url.includes('signup') || this.router.url.includes('login');
    });
  }
}

import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { SeatSelectionComponent } from '../seat-selection/seat-selection.component';
import { FormsModule } from '@angular/forms';

@Component({
  standalone: true,
  selector: 'app-movie-details',
  imports: [CommonModule, SeatSelectionComponent, FormsModule],
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css'],
})
export class MovieDetailsComponent implements OnInit {
  movieId: string | null = null;
  movie: any = {}; // Movie details
  theatres: any[] = []; // List of theatres showing this movie

  isSeatSelectionOpen = false;
  selectedDate: string | null = null;
  selectedTime: string = '';
  bookedSeats: any = {};

  timeDifferenceInMinutes: number = 0;
  minutesLeft: number = 0;
  bookedSeatNumbers: string = '';

  formatBookedSeats(): void {
    if (this.bookedSeats[this.selectedTime]) {
      // Map through the seats and join them into a string
      this.bookedSeatNumbers = this.bookedSeats[this.selectedTime]
        .map((seat: { number: any }) => seat.number)
        .join(', ');
    }
  }

  today = new Date().toJSON().split('T')[0];
  newDate = new Date(new Date().setDate(new Date().getDate() + 5))
    .toJSON()
    .split('T')[0];

  constructor(private route: ActivatedRoute, private router: Router) {}

  availableTimings = ['10:00 AM', '1:00 PM', '4:00 PM', '7:00 PM'];

  seats: any[] = [
    [
      { number: 'A1', price: 90, selected: false, booked: false },
      { number: 'A2', price: 90, selected: false, booked: false },
      { number: 'A3', price: 90, selected: false, booked: false },
      { number: 'A4', price: 90, selected: false, booked: false },
      { number: 'A5', price: 90, selected: false, booked: false },
    ],
    [
      { number: 'B1', price: 120, selected: false, booked: false },
      { number: 'B2', price: 120, selected: false, booked: false },
      { number: 'B3', price: 120, selected: false, booked: false },
      { number: 'B4', price: 120, selected: false, booked: false },
      { number: 'B5', price: 120, selected: false, booked: false },
    ],
    [
      { number: 'C1', price: 150, selected: false, booked: false },
      { number: 'C2', price: 150, selected: false, booked: false },
      { number: 'C3', price: 150, selected: false, booked: false },
      { number: 'C4', price: 150, selected: false, booked: false },
      { number: 'C5', price: 150, selected: false, booked: false },
    ],
    [
      { number: 'D1', price: 180, selected: false, booked: false },
      { number: 'D2', price: 180, selected: false, booked: false },
      { number: 'D3', price: 180, selected: false, booked: false },
      { number: 'D4', price: 180, selected: false, booked: false },
      { number: 'D5', price: 180, selected: false, booked: false },
    ],
    [
      { number: 'E1', price: 230, selected: false, booked: false },
      { number: 'E2', price: 230, selected: false, booked: false },
      { number: 'E3', price: 230, selected: false, booked: false },
      { number: 'E4', price: 230, selected: false, booked: false },
      { number: 'E5', price: 230, selected: false, booked: false },
    ],
    [
      { number: 'F1', price: 290, selected: false, booked: false },
      { number: 'F2', price: 290, selected: false, booked: false },
      { number: 'F3', price: 290, selected: false, booked: false },
      { number: 'F4', price: 290, selected: false, booked: false },
      { number: 'F5', price: 290, selected: false, booked: false },
    ],
  ];

  openSeatSelection(timing: string) {
    const now = new Date();
    const selectedDateTime = new Date(this.selectedDate + ' ' + timing);

    // Check if the booking time is 15 minutes before the showtime
    this.timeDifferenceInMinutes =
      (selectedDateTime.getTime() - now.getTime()) / (1000 * 60);

    if (!this.selectedDate) {
      alert('Please select a show date.');
      return;
    }

    if (this.timeDifferenceInMinutes < 15) {
      alert(
        'You can no longer book seats for this show. Please select another showtime.'
      );
      return;
    }

    this.selectedTime = timing;
    this.isSeatSelectionOpen = true;
  }

  closeSeatSelection() {
    debugger;
    // const seatSelectionModal = document.getElementById('seatSelectionModal');
    // if (seatSelectionModal) {
    //   seatSelectionModal.style.display = 'none';
    // }
    this.isSeatSelectionOpen = false;
  }

  loadBookedSeatsForShowtime() {
    const bookedSeats = localStorage.getItem(
      `${this.movieId}-${this.selectedDate}-${this.selectedTime}`
    );
    if (bookedSeats) {
      const bookedSeatNumbers = JSON.parse(bookedSeats);
      this.seats.forEach((row) => {
        row.forEach((seat: { number: any; booked: boolean }) => {
          if (bookedSeatNumbers.includes(seat.number)) {
            seat.booked = true;
          }
        });
      });
    }
  }

  onConfirmBooking(event: any) {
    const { selectedSeats } = event;

    // Save booked seats to localStorage
    const bookedSeats = selectedSeats.map(
      (seat: { number: any }) => seat.number
    );
    localStorage.setItem(
      `${this.movieId}-${this.selectedDate}-${this.selectedTime}`,
      JSON.stringify(bookedSeats)
    );

    this.bookedSeats[this.selectedTime] = selectedSeats;
    this.proceedToPayment(event.totalPrice);
  }

  calculateTimeLeftForMovie() {
    const now = new Date();
    const movieStartTime = new Date(
      this.selectedDate + ' ' + this.selectedTime
    );
    const timeLeftInMinutes =
      (movieStartTime.getTime() - now.getTime()) / (1000 * 60);

    if (timeLeftInMinutes < 0) {
      this.minutesLeft = 0; // Movie has already started
    } else {
      this.minutesLeft = Math.ceil(timeLeftInMinutes);
    }
  }

  confirmBooking() {
    debugger;
    const selectedSeats = this.seats.flat().filter((seat) => seat.selected);
    if (selectedSeats.length > 0) {
      const seatDetails = selectedSeats.map((seat) => ({
        number: seat.number,
        price: seat.price,
      }));

      const totalPrice = seatDetails.reduce((sum, seat) => sum + seat.price, 0);
      const gstRate = 0.18;
      const gstAmount = totalPrice * gstRate;
      const finalAmount = totalPrice + gstAmount;

      this.router.navigate(['/payment'], {
        state: {
          selectedSeats,
          totalPrice,
          showTime: this.selectedTime,
          showDate: this.selectedDate,
        },
      });
    } else {
      alert('Please select at least one seat.');
    }
  }

  proceedToPayment(totalPrice: number) {
    console.log(`Total payment to be made: ₹${totalPrice}`);
    // Navigate to payment component or show payment UI
  }

  movies: any;
  theatresData: any;

  // Example data for movies and theatres
  // movies = [
  //   { id: 1, title: 'Movie 1', description: 'Description 1', image: 'movie1.jpg' },
  //   { id: 2, title: 'Movie 2', description: 'Description 2', image: 'movie2.jpg' },
  //   { id: 3, title: 'Movie 3', description: 'Description 3', image: 'movie3.jpg' },
  // ];

  // theatresData = {
  //   1: [
  //     {
  //       name: 'Theatre 1',
  //       timings: ['10:00 AM', '1:00 PM', '4:00 PM', '7:00 PM'],
  //     },
  //     {
  //       name: 'Theatre 2',
  //       timings: ['11:00 AM', '2:00 PM', '5:00 PM'],
  //     }
  //   ],
  //   2: [
  //     {
  //       name: 'Theatre 3',
  //       timings: ['12:00 PM', '3:00 PM', '6:00 PM'],
  //     }
  //   ],
  //   3: [
  //     {
  //       name: 'Theatre 4',
  //       timings: ['9:00 AM', '12:00 PM', '6:00 PM'],
  //     }
  //   ]
  // };

  getTheatreData() {
    let theatresDetails = localStorage.getItem('theatres');
    return theatresDetails ? JSON.parse(theatresDetails) : {};
  }

  getMoviesData() {
    let moviesDetails = localStorage.getItem('movies');
    return moviesDetails ? JSON.parse(moviesDetails) : [];
  }

  ngOnInit(): void {
    this.movies = this.getMoviesData();
    this.theatresData = this.getTheatreData();
    // Get the movie ID from the URL
    this.movieId = this.route.snapshot.paramMap.get('id');
    this.loadMovieDetails();
    this.loadTheatres();
    this.formatBookedSeats();
  }

  loadMovieDetails(): void {
    // Find the movie by ID
    this.movie = this.movies.find(
      (movie: { id: string | null }) => movie.id == this.movieId
    );
  }

  loadTheatres(): void {
    // Load theatres based on movie ID
    if (this.movieId) {
      this.theatres = this.theatresData[this.movieId] || [];
    }
  }

  bookShow(theatreName: string, timing: string): void {
    // Logic to book the show
    alert(
      `You have booked ${this.movie.title} at ${theatreName} for ${timing}`
    );
  }

  selectShowtime(theatreName: string, showtime: string) {
    debugger;
    console.log(`Selected showtime: ${showtime}`);
    this.openSeatSelectionModal(); // Open seat selection modal
  }

  openSeatSelectionModal() {
    const seatSelectionModal = document.getElementById('seatSelectionModal');
    if (seatSelectionModal) {
      seatSelectionModal.style.display = 'block';
    }
  }
}

import { Component } from '@angular/core';

@Component({
  standalone: true,
  imports: [],
  selector: 'app-not-found',
  template: `<h2>404 - Page Not Found</h2>`,
})
export class NotFoundComponent {}

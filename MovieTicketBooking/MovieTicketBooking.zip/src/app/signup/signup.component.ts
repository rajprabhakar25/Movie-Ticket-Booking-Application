import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../auth.service';
import {
  AbstractControl,
  FormsModule,
  ReactiveFormsModule,
  ValidationErrors,
  ValidatorFn,
  Validators,
} from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css',
  imports: [FormsModule, RouterLink, ReactiveFormsModule, CommonModule],
})
export class SignupComponent {
  // name: string = '';
  // email: string = '';
  // phone: string = '';
  // password: string = '';
  // confirmPass: string = '';
  formData: FormGroup;

  constructor(private authService: AuthService, private router: Router) {
    this.formData = new FormGroup(
      {
        name: new FormControl('', [
          Validators.required,
          Validators.minLength(3),
        ]),
        email: new FormControl('', [
          Validators.required,
          Validators.email,
          Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+.[a-z]{2,4}$'),
        ]),
        phone: new FormControl('', [
          Validators.required,
          Validators.pattern('^[0-9]{10}$'),
          Validators.maxLength(10),
          Validators.minLength(10),
        ]), // Phone number validation
        password: new FormControl('', [
          Validators.required,
          Validators.minLength(6),
          Validators.pattern(
            '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$'
          ),
        ]),
        confirmPassword: new FormControl('', [Validators.required]), // Confirm password field
      },
      { validators: this.passwordMatchValidator }
    ); // Add custom validator for password match
  }

  // passwordMatchValidator(group: FormGroup): { [key: string]: boolean } | null {
  //   const password = group.get('password')?.value;
  //   const confirmPassword = group.get('confirmPassword')?.value;
  //   return password === confirmPassword ? null : { notMatching: true };
  // }

  passwordMatchValidator: ValidatorFn = (
    control: AbstractControl
  ): ValidationErrors | null => {
    const formGroup = control as FormGroup;
    const password = formGroup.get('password')?.value;
    const confirmPassword = formGroup.get('confirmPassword')?.value;

    return password === confirmPassword ? null : { notMatching: true };
  };

  signup() {
    if (this.formData.valid) {
      const userData = this.formData.value;
      this.authService.signup(userData);
      // Store user data logic (e.g., localStorage)
      alert('Successfully Registered');
      this.router.navigate(['/login']);
    } else {
      alert('Form Data is invalid');
    }
  }
}
